/**
 * This class is used to load the configuration parameters from properties file
 * I have applied the Singleton design pattern in this
 */
package com.virtusa.assignment.configs;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Properties;

import com.virtusa.assignment.exceptions.CSVConfigParamsMissingException;
import com.virtusa.assignment.main.TestCSV;

public class CSVConfig implements Serializable{
	
	private static final long serialVersionUID = 23423423L;
	private static CSVConfig config = null;
	private String fileLocation;
	private String lineSeperator;


	private CSVConfig(String location, String lineSeperator) {
		this.fileLocation = location;
		this.lineSeperator = lineSeperator;
	}

	public static CSVConfig getCSVConfigObject() {
		// here using the try with resource so no need to use finally block to close these resources
		try (InputStream inputStrm = TestCSV.class.getClassLoader().getResourceAsStream("csv-config.properties")){
			if (config == null) {
				synchronized (CSVConfig.class) {
					if (config == null) {
						if (null != inputStrm) {
							Properties prop = new Properties();
							prop.load(inputStrm);
							String fileLocation = prop.getProperty("csvFileLocation");
							String splitDelimeter = prop.getProperty("lineSplitDelimeter");
							if(null != fileLocation && !fileLocation.isEmpty() 
									&& null != splitDelimeter && !splitDelimeter.isEmpty()) {
								config = new CSVConfig(fileLocation, splitDelimeter);
							}else {
								//throwing custom exception
								throw new CSVConfigParamsMissingException("Config Params are missing in property file.");
							}
						}
					}
				}
			}

		} catch (IOException ex) {
			System.out.println("Exception occured in CSVConfig :: getCSVConfigObject: "+ex.getMessage());
			ex.printStackTrace();
		}
		return config;
	}

	/**
	 * @return the fileLocation
	 */
	public String getFileLocation() {
		return fileLocation;
	}

	/**
	 * @return the lineSeperator
	 */
	public String getLineSeperator() {
		return lineSeperator;
	}

	/**
	 * Overriding this clone method to avoid the cloning of this class as single instance 
	 * of this class will be created only.
	 */
	@Override
	protected Object clone() {
		return new CloneNotSupportedException();
	}
	

	/**
	 * Using this read resolve, avoiding the de-serialization object
	 * of this class.
	 */
	public Object readResolve() {
		return config;
	}
}
