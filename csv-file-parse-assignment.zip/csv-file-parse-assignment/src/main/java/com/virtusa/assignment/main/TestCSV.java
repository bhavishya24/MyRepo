/**
 * This is the main class which will print the employees reading from the 
 * CSV file.
 */
package com.virtusa.assignment.main;

import java.util.List;

import com.virtusa.assignment.configs.CSVConfig;
import com.virtusa.assignment.others.Employee;
import com.virtusa.assignment.util.CSVUtil;

public class TestCSV {

	public static void main(String[] args) {
		CSVConfig config = CSVConfig.getCSVConfigObject();
		String filePath = config.getFileLocation();
		String lineSeperator = config.getLineSeperator();
		List<Employee> empList = CSVUtil.readEmployeeDataFromCSV(filePath, lineSeperator);
		//used java 8 lambda feature
		empList.forEach(emp-> {
			System.out.println("First Name: "+emp.getFirstName()+"	|	Last Name: "+emp.getLastName()+"	|	City: "+emp.getCity()
			+"	|	Organization: "+emp.getCompanyName());
		});
	}

}
