package com.virtusa.assignment.exceptions;

public class CSVConfigParamsMissingException extends RuntimeException {
	public CSVConfigParamsMissingException(String msg) {
		super(msg);
	}
}