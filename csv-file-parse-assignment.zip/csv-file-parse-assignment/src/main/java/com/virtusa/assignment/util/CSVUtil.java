package com.virtusa.assignment.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.assignment.exceptions.CSVDataFormatMismatchException;
import com.virtusa.assignment.others.Employee;

public class CSVUtil {

	public static List<Employee> readEmployeeDataFromCSV(String fileLocation, String lineDelimeter) {
		List<Employee> empList = new ArrayList<Employee>();
		Path filePath = Paths.get(fileLocation);
		// using try with resource, so no need to mention the finally block to close the
		// resources
		try (BufferedReader br = Files.newBufferedReader(filePath)) {
			// read the first line from the text file
			String line = br.readLine();
			// loop until all lines are read
			while (line != null) {
				// use string.split to load a string array with the values from
				String[] attributes = line.split(lineDelimeter);
				Employee emp = createEmployee(attributes);
				empList.add(emp);
				// read next line before looping if end of file reached, line would be null
				line = br.readLine();
			}

		} catch (IOException ioEx) {
			System.out.println("IOException occured inside readEmployeeDataFromCSV() in CSVUtil " + ioEx.getMessage());
			ioEx.printStackTrace();
		}
		return empList;
	}

	/**
	 * This method is used to create the object of the Employee class based on the
	 * data coming from the CSV file
	 * 
	 * @param attributesArray
	 * @return
	 */
	private static Employee createEmployee(String[] attributesArray) {
		if(attributesArray.length == 4) {
			String firstName = attributesArray[0];
			String lastName = attributesArray[1];
			String city = attributesArray[2];
			String compName = attributesArray[3];
			return new Employee(firstName, lastName, city, compName);
		}else {
			throw new CSVDataFormatMismatchException("format is mismatch in CSV file so there is problem in parsing.");
		}
	}
}
