package com.virtusa.assignment.others;

/**
 * @author bhavishya_s
 * This is the Employee, will be used to create the employee objects
 */
public class Employee {
	private String firstName;
	private String lastName;
	private String city;
	private String companyName;
	
	public Employee(String firstName, String lastName, String city, String compName) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.city = city;
		this.companyName = compName;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	
	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}
}
