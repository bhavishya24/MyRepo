package com.virtusa.assignment.exceptions;

public class CSVDataFormatMismatchException extends RuntimeException {
	public CSVDataFormatMismatchException(String msg) {
		super(msg);
	}
}
